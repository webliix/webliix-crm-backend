INSERT INTO roles(name)
VALUES ('SUPER_ADMIN');

INSERT INTO roles(name)
VALUES ('ADMIN');

INSERT INTO roles(name)
VALUES ('MANAGER');

INSERT INTO roles(name)
VALUES ('EMPLOYEE');
