ALTER TABLE quotations
    ADD COLUMN converted BOOLEAN DEFAULT FALSE,
    ADD COLUMN converted_at TIMESTAMP;
